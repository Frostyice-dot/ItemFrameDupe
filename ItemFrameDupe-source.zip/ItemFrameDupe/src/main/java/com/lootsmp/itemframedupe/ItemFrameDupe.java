package com.lootsmp.itemframedupe;

import org.bukkit.Material;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

public final class ItemFrameDupe extends JavaPlugin implements Listener {
    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ItemFrameDupe enabled.");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemFrameInteract(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!(event.getRightClicked() instanceof ItemFrame frame)) return;

        Player player = event.getPlayer();
        if (!player.getInventory().getItemInMainHand().getType().isAir()) return;

        ItemStack framedItem = frame.getItem();
        if (framedItem == null || framedItem.getType() == Material.AIR) return;

        // Replace vanilla removal with a silent, controlled 2-copy payout.
        event.setCancelled(true);
        ItemStack original = framedItem.clone();
        ItemStack duplicate = framedItem.clone();
        frame.setItem(new ItemStack(Material.AIR));

        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(original, duplicate);
        leftovers.values().forEach(leftover ->
                player.getWorld().dropItemNaturally(player.getLocation(), leftover));
    }
}
