ItemFrameDupe 1.0.0 - source project
Target: Paper/Purpur 1.21.11, Java 21+

Behavior:
- Main-hand right-click on an occupied item frame while holding an empty hand
  removes the framed stack and gives the player TWO copies.
- If inventory space is insufficient, leftovers drop at the player's feet.
- Empty-frame placement and interactions with non-item-frame entities are unchanged.
- No player-facing messages or commands.

Build:
1. Install Java 21 and Apache Maven.
2. Open a terminal in this folder.
3. Run: mvn clean package
4. The plugin jar will be at target/itemframedupe-1.0.0.jar
5. Put that jar in the server's plugins folder and restart the server.

This is intentionally an economy-breaking mechanic. Test on a backup/test world first.
